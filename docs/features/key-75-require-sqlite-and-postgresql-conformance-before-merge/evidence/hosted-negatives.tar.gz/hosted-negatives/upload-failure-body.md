This is an authorized, deliberate failure demonstration for KEY-75. **Do not merge this PR.** It remains open for evidence collection and required-check enforcement observation.

**Linear issue:** https://linear.app/keynes/issue/KEY-75/require-sqlite-and-postgresql-conformance-before-merge
**Specification:** https://github.com/keynes-dev/keynes/blob/d27d906f4608af9281466f6098b486ce399d6dc5/docs/features/key-75-require-sqlite-and-postgresql-conformance-before-merge/spec.md
**Prerequisites:** The implementation under review in #36 is included in this branch; it is not yet merged.
**Acceptance:** https://github.com/keynes-dev/keynes/blob/d27d906f4608af9281466f6098b486ce399d6dc5/docs/features/key-75-require-sqlite-and-postgresql-conformance-before-merge/evidence/acceptance.md

## Why this change exists

Only the five conformance artifact upload paths point to an intentionally nonexistent runner temporary directory. Both authority runners keep their normal output location. This proves successful execution cannot rescue failed artifact retention.

## What changed and how it works

The demonstration is based on published implementation `d27d906f4608af9281466f6098b486ce399d6dc5` and changes only `.github/workflows/ci.yml` relative to that revision. The rest of the implementation is inherited from #36. The existing paired runner owns process execution, report validation and retained identity; the native runner owns disposable Docker fixtures and cleanup. No product state, transaction, retry or compatibility behavior is redesigned.

## Verification and evidence boundaries

Exact patch and file scope were verified before publication. The native assertion transformation previously ran locally on disposable revision `3af80e6f2cb951027f51f491df0728df4debb97d`: SQLite 37 passed, native 207 passed/1 deliberately failed, paired exit 1, cleanup passed. That is earlier local evidence, not hosted evidence for this revision. The missing-upload transformation was scope-checked against the five existing upload targets.

Hosted run [33945569495](https://github.com/keynes-dev/keynes/actions/runs/33945569495) tested merge `83096dbe54bd0dd7f22947e592b703e41ecaf95e` for PR head `5ab53890c68c15edc3b52b881dc65d27021a46be`. `Repository and tests` passed. `Run both conformance authorities` succeeded, proving the paired command completed successfully; `Retain conformance evidence` and `Confirm artifact retention` failed, so the conformance check failed. The error identifies the intentionally missing upload directory. GitHub returned zero artifacts for this run. Per-scenario reports are intentionally unavailable because retention failed; no report counts are inferred. Required-check policy, blocked-merge observation and cancellation are separate evidence. No merge will be used as a test.

## Review guide

1. Compare `d27d906f4608af9281466f6098b486ce399d6dc5...5ab53890c68c15edc3b52b881dc65d27021a46be` to inspect the sole deliberate failure transformation in `.github/workflows/ci.yml`.
2. Review #36 for the underlying implementation and evidence boundaries.
3. Inspect the `SQLite and PostgreSQL conformance` job and retained evidence for this exact PR candidate.

## Follow-up work

Retain hosted evidence for KEY-75, observe effective required-check enforcement, and close the disposable demonstration after evidence collection. No product change from this deliberate failure should merge.
