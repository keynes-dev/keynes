# KEY-75 hosted negative demonstrations

Both ready PRs remain open and unmerged. They inherit reviewed implementation `d27d906f4608af9281466f6098b486ce399d6dc5` and preserve the exact prepared single-file failure transformations. Main checkout and policy were not changed by this work.

| Demonstration | PR | Head | Tested merge | Run | Check |
| --- | --- | --- | --- | --- | --- |
| Native assertion failure | #41 | 347abd905ddd201ab23ea6f14cb88a316d98e0fa | b933a50693e58afda1468069f34f0c53f9116010 | 33945566900 | Failure |
| Artifact upload failure | #42 | 5ab53890c68c15edc3b52b881dc65d27021a46be | 83096dbe54bd0dd7f22947e592b703e41ecaf95e | 33945569495 | Failure |

Both `Repository and tests` checks passed. Both conformance checks use the exact name `SQLite and PostgreSQL conformance` and GitHub Actions app ID 15368. Tested merge commits were extracted from checkout logs and independently verified against their GitHub parent commits.

Native failure: SQLite 37 passed; native 207 passed and one intentional Resource-definition afterEach assertion failed. Cleanup passed for both authorities. Upload and receipt succeeded. Artifact 9963241458 is retained in `native-failure/artifact.zip`; SHA-256 de739b5143e3e9fa928ba272c296e2e7592d5200276ebb94b8a48493e384223f matches GitHub. Expiry: 2026-09-19T04:51:42Z. Four expected failure files exist; the native success record is absent. Report hashes and published source contract/lockfile/installation hashes match; sanitization scanning passed.

Upload failure: the paired authority step succeeded; only upload and receipt failed. GitHub reports zero artifacts. Safe log excerpts identify the intentionally missing directory. Individual report counts cannot be inspected because retention intentionally failed. The successful paired command requires both authority executions and local cleanup to pass; VM disposal remains the forced cleanup boundary.

Each subdirectory contains `evidence.json` with exact checks, app ID, steps, identities and artifact metadata. This collection does not claim branch-policy enforcement or hosted cancellation; the parent collects those independently. PRs are left open for the authorized policy proof and must not merge.
