# KEY-75 local negative demonstrations

Provisional base: `d4f2131c95dd34f6db675931108ee4c30d02e73d`. Each attempt used a distinct committed disposable revision, an isolated detached worktree, frozen dependencies, Node 26.5.0, and a fresh external output directory. Attempts ran sequentially. These are local real-authority demonstrations, not hosted checks. Later cancellation fixes are outside this base.

| Attempt | Revision | SQLite | Native | Exit | Cleanup | Seconds |
| --- | --- | --- | --- | --- | --- | --- |
| native-assertion | `864161dcb33052e391c446c49fe941c0f9f74cda` | 37 passed / 0 failed / 0 skipped | 207 passed / 1 failed / 0 skipped | 1 | passed, passed | 37.18 |
| skipped-shared | `c76a97ff0d84035bcc3f7c6f4b501128a7fe4e29` | 36 passed / 0 failed / 1 skipped | 207 passed / 0 failed / 1 skipped | 1 | passed, passed | 29.31 |
| empty-native | `bfb073fdb768819213cdc33491d9cd3edede13e5` | 37 passed / 0 failed / 0 skipped | 171 passed / 0 failed / 0 skipped | 1 | passed, passed | 36.3 |
| docker-unavailable | `192b2881ed2bee0394ffa46f661dc5dd8f072122` | 37 passed / 0 failed / 0 skipped | NOT RUN | 1 | passed, passed | 4.93 |

All manifests match their exact demonstration revision and remain failed. All available referenced file SHA-256 values match. Native success records are absent. Sanitized JSON passes the credential/private-fixture scan. Exact attempt-owned container and network inspection returns nonzero after every run, confirming absence. Worktree status remains clean. `summary.json` retains commands, counts, observed environment, safe stages, fixture IDs, hashes, and cleanup readback.

The intentional failure runs the first real shared Resource-definition assertion and fails its native-only afterEach assertion. The skipped demonstration changes the first shared registration to it.skip for both authorities. The empty demonstration replaces only the native aggregate with export {}; the remaining 171 native tests pass but the aggregate has no tests and the command fails. The unavailable-Docker demonstration points DOCKER_HOST at an unused loopback endpoint; SQLite passes and native tests are NOT RUN.

Provider-free corrupted/stale-evidence and cleanup-failure regressions are separate fixture evidence. Hosted failure/upload/protected-branch enforcement is NOT RUN here.
