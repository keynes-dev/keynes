# KEY-75 hosted success evidence

PR #36 head `810e5a98f221e1e3351b2b5de6fe0cbf0dc6ce20`, base `903251532497cc6ea3b4e062383db07ed8438eb3`. The actual tested merge commit is `915fb0be8de29182597dc9751986d14cf214b833`; GitHub commit parents independently match that base and head.

CI run [33943777211](https://github.com/keynes-dev/keynes/actions/runs/33943777211), attempt 1, completed successfully. Job/check [101246034785](https://github.com/keynes-dev/keynes/actions/runs/33943777211/job/101246034785) is exactly `SQLite and PostgreSQL conformance`, owned by GitHub Actions app ID `15368`. Both qualification and artifact-retention confirmation steps succeeded.

Downloaded artifact `9962696762`, `conformance-915fb0be8de29182597dc9751986d14cf214b833-33943777211-1-conformance`. Its ZIP SHA-256 matches the GitHub artifact digest `7123da588142762cb3d2c8518e87e479922e2c383f67186f755cf355b0b22916`. GitHub expiration: `2026-09-19T04:11:48Z`. The archive is retained locally as `artifact.zip`.

The archive contains exactly the five allowed files: `manifest.json`, `sqlite.vitest.json`, `postgresql.json`, `postgresql.json.vitest.json`, and `postgresql.json.observations.json`. Every manifest file reference hash matches. Native acceptance matches the report, tested revision, contract, archive and installation digests; manifest inputs also match source bytes fetched at the tested merge commit. Attempt and native fixture identity match retained observations.

Strict report validation passed: SQLite 37/37; native 208/208; all 37 shared full names match; required native-only inventory is complete. Both cleanup outcomes passed. JSON credential/private-fixture scanning passed. Observed versions and image digests are retained in `verification.json`; source, check, artifact and retention metadata are retained in `metadata.json`.

This proves hosted success and artifact retention for the stated revision. It does not prove hosted negative/cancellation/upload-failure behavior or required-check branch-policy enforcement.
