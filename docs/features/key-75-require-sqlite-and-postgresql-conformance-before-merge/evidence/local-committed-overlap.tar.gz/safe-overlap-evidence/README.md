Four exact paired attempts on clean commit 5a4d12690fd4c36dbff21b846e3ced38b0ea7bfe.

The stderr-only pair returned 0 and 1; both native reports had 208 passing assertions, but the failed child exit prevented qualification. The both-streams pair returned 0 and 0. All native cleanup observations passed.

The native invocation did not execute the temporary capture shim: both native-specific log and exit files stayed empty. Raw private logs are excluded. These attempts do not establish the cause of intermittent process failure. No source edits were used.
