#!/bin/sh
case "$*" in
  *packages/postgresql/test/system/*)
    /opt/homebrew/bin/pnpm "$@" >> /var/folders/n2/z5gzj5hn7vxdxqr14t6xhjdh0000gn/T/keynes-native-stderr-zmtkxr3m/a.native-both.private.log 2>&1
    native_status=$?
    printf "%s\n" "$native_status" >> /var/folders/n2/z5gzj5hn7vxdxqr14t6xhjdh0000gn/T/keynes-native-stderr-zmtkxr3m/a.native-exit.txt
    exit "$native_status"
    ;;
  *) exec /opt/homebrew/bin/pnpm "$@" ;;
esac
