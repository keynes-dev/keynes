**Linear issue:** [KEY-75](https://linear.app/keynes/issue/KEY-75/require-sqlite-and-postgresql-conformance-before-merge)
**Specification:** [Conformance specification](https://github.com/keynes-dev/keynes/blob/d27d906f4608af9281466f6098b486ce399d6dc5/docs/features/key-75-require-sqlite-and-postgresql-conformance-before-merge/spec.md)
**Prerequisites:** None; this is a temporary acceptance demonstration of the proposed feature.
**Acceptance:** [Feature proposal PR #36](https://github.com/keynes-dev/keynes/pull/36). Cancellation evidence will identify this PR's exact run and check.

## Purpose and behavior

This temporary ready PR runs unchanged source tree from `d27d906f4608af9281466f6098b486ce399d6dc5` under isolated no-op commit `ed5a150381ec800c911f97b1c8e72735a5644911` against `main` to demonstrate that cancelling the hosted conformance execution produces a nonpassing check. The demonstration adds no diagnostic source changes. Do not merge this PR; it will remain open until its evidence has been retained and the acceptance coordinator closes it.

The existing runner owns the isolated native fixtures and bounded cleanup. GitHub-hosted VM teardown is the outer cleanup boundary if cancellation interrupts the runner before it can retain cleanup observations. A cancelled run cannot substitute for a passing conformance attempt.

## Verification and evidence boundaries

The remote demonstration branch was verified absent before creation and points at an isolated empty commit whose parent is the repair commit and whose source tree is identical. Hosted cancellation, check conclusion, and available artifact retention are NOT RUN at PR creation. Cancellation will target only this PR's run, after its conformance execution step is observed in progress. No native startup stage will be claimed unless directly observed.

## Review guide

1. Confirm head `ed5a150381ec800c911f97b1c8e72735a5644911` has the exact source tree of `d27d906f4608af9281466f6098b486ce399d6dc5`; the empty commit isolates this cancellation check from the feature PR.
2. Inspect the conformance execution step, targeted run cancellation, and cancelled check conclusion.
3. Inspect retained artifact metadata and distinguish observed cleanup from hosted VM termination.

Follow-up: retain exact evidence and close this temporary PR without merging. No UI changes apply.
