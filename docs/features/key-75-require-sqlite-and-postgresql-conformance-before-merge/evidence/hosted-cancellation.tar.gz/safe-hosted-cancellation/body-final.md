**Linear issue:** [KEY-75](https://linear.app/keynes/issue/KEY-75/require-sqlite-and-postgresql-conformance-before-merge)
**Specification:** [Conformance specification](https://github.com/keynes-dev/keynes/blob/d27d906f4608af9281466f6098b486ce399d6dc5/docs/features/key-75-require-sqlite-and-postgresql-conformance-before-merge/spec.md)
**Prerequisites:** None; this is a temporary acceptance demonstration of the proposed feature.
**Acceptance:** [Feature proposal PR #36](https://github.com/keynes-dev/keynes/pull/36). Cancellation evidence will identify this PR's exact run and check.

## Purpose and behavior

This temporary ready PR runs unchanged source tree from `d27d906f4608af9281466f6098b486ce399d6dc5` under isolated no-op commit `ed5a150381ec800c911f97b1c8e72735a5644911` against `main` to demonstrate that cancelling the hosted conformance execution produces a nonpassing check. The demonstration adds no diagnostic source changes. Do not merge this PR; it will remain open until its evidence has been retained and the acceptance coordinator closes it.

The existing runner owns the isolated native fixtures and bounded cleanup. GitHub-hosted VM teardown is the outer cleanup boundary if cancellation interrupts the runner before it can retain cleanup observations. A cancelled run cannot substitute for a passing conformance attempt.

## Verification and evidence boundaries

The remote demonstration branch was verified absent before creation and points at an isolated empty commit whose parent is the repair commit and whose source tree is identical. [Run 33945639038](https://github.com/keynes-dev/keynes/actions/runs/33945639038) and [conformance check 101251085053](https://github.com/keynes-dev/keynes/actions/runs/33945639038/job/101251085053) concluded **cancelled**. Cancellation targeted only this unique-head run after its conformance execution step was observed in progress for 53.35 seconds; the native substage was not observed. Artifact 9963246206 was retained and its downloaded ZIP SHA256 matches the API digest: `90e400b86c62bd7eb72ae825f3227cb4ea7ae068e4113d4067abcbdf520b5ef0`. It contains the 37-pass SQLite report only. Native report, native acceptance, manifest, and fixture cleanup observations were not retained. The runner logged orphan-process cleanup; individual fixture cleanup remains unconfirmed, with hosted VM termination as the outer boundary.

## Review guide

1. Confirm head `ed5a150381ec800c911f97b1c8e72735a5644911` has the exact source tree of `d27d906f4608af9281466f6098b486ce399d6dc5`; the empty commit isolates this cancellation check from the feature PR.
2. Inspect the conformance execution step, targeted run cancellation, and cancelled check conclusion.
3. Inspect retained artifact metadata and distinguish observed cleanup from hosted VM termination.

Follow-up: retain exact evidence and close this temporary PR without merging. No UI changes apply.
