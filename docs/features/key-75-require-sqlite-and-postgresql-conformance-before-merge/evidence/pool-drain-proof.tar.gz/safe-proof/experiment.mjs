import {createRequire} from 'node:module';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {randomUUID,randomBytes} from 'node:crypto';
import {writeFile} from 'node:fs/promises';
const require=createRequire('/Users/shubhankarsharan/Desktop/keynes/packages/postgresql/package.json');
const {Client,Pool}=require('pg');
const exec=promisify(execFile);const runId='keynes-drain-proof-'+randomUUID();const password=randomBytes(24).toString('base64url');
const image='postgres:18.6@sha256:06cad38a5d9f5d24b4d83d86def30795d5e4b757fedbf5281172b576dedcd941';
let started=false;let administrator;const result={sourceCommit:'5a4d12690fd4c36dbff21b846e3ced38b0ea7bfe',injection:'Delay only connection.end wire request 50ms; preserve Client.end synchronous state change',image,arms:[],cleanup:'unconfirmed'};
try{
 await exec('docker',['run','--detach','--rm','--name',runId,'--env','POSTGRES_PASSWORD','--publish','127.0.0.1::5432',image],{env:{...process.env,POSTGRES_PASSWORD:password}});started=true;
 const port=(await exec('docker',['port',runId,'5432/tcp'])).stdout.trim().split(':').at(-1);const url=new URL('postgresql://postgres@127.0.0.1/postgres');url.password=password;url.port=port;
 const deadline=Date.now()+30000;
 while(true){const client=new Client({connectionString:url.href,connectionTimeoutMillis:500});try{await client.connect();administrator=client;break;}catch{await client.end();if(Date.now()>deadline)throw new Error('readiness timeout');await new Promise(r=>setTimeout(r,100));}}
 result.serverVersion=(await administrator.query('show server_version_num')).rows[0].server_version_num;
 for(const waitForSocket of [false,true]){
  const database=waitForSocket?'drain_control':'drain_current';await administrator.query('create database '+database);
  const databaseUrl=new URL(url);databaseUrl.pathname='/'+database;const pool=new Pool({connectionString:databaseUrl.href});const events=[];const start=Date.now();const event=(name,fields={})=>events.push({name,ms:Date.now()-start,...fields});
  pool.on('error',error=>event('pool-error',{code:error.code,message:error.message}));
  const client=await pool.connect();await client.query('select 1');
  const originalEnd=client.connection.end.bind(client.connection);
  client.connection.end=()=>{event('wire-end-delayed');setTimeout(()=>{event('wire-end-sent');originalEnd();},50);};
  const socketEnd=new Promise(resolve=>client.once('end',()=>{event('client-end');resolve();}));
  client.release();event('client-released');await pool.end();event('pool-end-resolved');
  if(waitForSocket)await socketEnd;
  event('drop-requested');await administrator.query('drop database '+database+' with (force)');event('drop-completed');
  await Promise.race([socketEnd,new Promise((_,reject)=>setTimeout(()=>reject(new Error('client end timeout')),2000).unref())]);
  await new Promise(resolve=>setTimeout(resolve,100));
  result.arms.push({waitForSocket,events});
 }
}catch(error){result.failure={name:error.name,code:error.code,message: /^readiness timeout|client end timeout$/.test(error.message)?error.message:'experiment failed'};process.exitCode=1;}
finally{await administrator?.end();if(started){try{await exec('docker',['stop',runId],{timeout:10000});result.cleanup='passed';}catch{result.cleanup='failed';process.exitCode=1;}}await writeFile(new URL('./result.json',import.meta.url),JSON.stringify(result,null,2)+'\n',{mode:0o600});process.stdout.write(JSON.stringify(result)+'\n');}
