Controlled real PostgreSQL18.6 cleanup experiment, not direct reproduction of the earlier unexplained Vitest exits.

The script generates credentials at runtime with randomBytes and passes them through an environment variable. No captured credential is present in the script or result. It delays only the actual pg connection.end wire request50ms, preserving Client.end synchronous state. Current Pool.end->DROP FORCE emitted57P01 before socket end; waiting actual client end prevented the error. The runner-owned Docker container was stopped successfully.
